#-------------------------------------------------#
# Title: Working with Functions
# Dev:   Jeremy Rabbe
# Date:  Nov 12, 2018
# ChangeLog: (Who, When, What)
#

#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------




# ---- Data Code ---- #

# Define the variables needed
objFileName = "C:\_PythonClass\Assignment06\Todo.txt"
strData = ""
dicRow = {}
lstTable = []





# ---- Processing Code ---- #

#Create a class to hold the Menu
class MenuFunctions(object):
    '''This class contains the functions for the User Menu'''

    # Function to open up file called by objFileName
    @staticmethod
    def FileOpen (objFileName):
        objFile = open(objFileName, "r") # "r" allows file to be read
        for line in objFile:
            strData = line.split(",")
            dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()

    #Function to Display data into rows
    @staticmethod
    def DisplayData(lstTable):
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    #Function to Save Data to file called by objFileName
    @staticmethod
    def SaveData ():
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")

    #Function to Remove a row of Data
    @staticmethod
    def RemoveData ():
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

    #Fuction to Add a row of Data
    @staticmethod
    def AddData ():
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)

    #Function to Display the Menu
    @staticmethod
    def DisplayMenu():
        print ("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)




# ---- Presentation (I/O) ---- #
MenuFunctions.FileOpen(objFileName)

while(True):
    MenuFunctions.DisplayMenu()
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line
    if (strChoice.strip() == '1'):
        MenuFunctions.DisplayData(lstTable)
        continue
    elif(strChoice.strip() == '2'):
        MenuFunctions.AddData()
        MenuFunctions.DisplayData(lstTable)
        continue
    elif(strChoice == '3'):
        MenuFunctions.RemoveData()
        MenuFunctions.DisplayData(lstTable)
        continue
    elif(strChoice == '4'):
        MenuFunctions.DisplayData(lstTable)
        MenuFunctions.SaveData()
        continue
    elif (strChoice == '5'):
        break #and Exit the program

